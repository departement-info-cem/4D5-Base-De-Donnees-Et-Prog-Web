
-- Cr�ation de la nouvelle table de liaison ClientsCompte





GO

-- Nouvelles contraintes FK







-- Remplir la table avec les relations Existantes





-- Enlever l'ancienne FK ClientID de la table Comptes.Compte




GO
-- Enlever le champs qui �tait l'ancienne FK ClientID de la table Comptes.Compte


