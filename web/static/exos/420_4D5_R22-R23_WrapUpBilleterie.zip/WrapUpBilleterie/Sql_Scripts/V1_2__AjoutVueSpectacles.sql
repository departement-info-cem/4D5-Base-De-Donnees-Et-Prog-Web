﻿

CREATE VIEW Spectacles.VW_SpectaclesRepresentationSpectateurs
AS
