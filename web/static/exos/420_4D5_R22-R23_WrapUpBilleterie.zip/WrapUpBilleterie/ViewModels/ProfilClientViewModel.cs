﻿using WrapUpBilleterie.Models;

namespace WrapUpBilleterie.ViewModels
{
    public class ProfilClientViewModel
    {
        /* Décommentez cette ligne lorsque vous serez à l'étape 6 */
        //public Client Client { get; set; } = null!;


        /* Décommentez cette ligne lorsque vous aurez complété et appliqué la migration 1.4 et que vous aurez scaffoldé vos données */
        //public List<CarteBancaireEnClair> Cartes { get; set; } = null!;
    }
}
