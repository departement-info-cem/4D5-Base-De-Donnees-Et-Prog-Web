
	CREATE DATABASE R19_Labo;
	GO
	
	-- Configurer un nouveau filegroup ici