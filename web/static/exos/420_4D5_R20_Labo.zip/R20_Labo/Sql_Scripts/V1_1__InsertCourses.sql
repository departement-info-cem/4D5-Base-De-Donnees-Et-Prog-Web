-- •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
--					  Courses
-- •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

USE SussyKart;
GO

INSERT INTO Courses.Course (Nom, NbTours, Difficulte)
VALUES
('Donut', 4, 'facile'),
('8 Classique', 3, 'normale'),
('Détours confondants', 4, 'difficile'),
('Bébé Circuit', 7, 'facile'),
('Bretzel Anguleux', 2, 'normale'),
('Sentier Couronne', 3, 'difficile');
GO
