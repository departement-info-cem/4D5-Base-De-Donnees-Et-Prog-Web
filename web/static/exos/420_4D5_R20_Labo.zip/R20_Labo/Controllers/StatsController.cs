﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using R20_Labo.Data;
using R20_Labo.Models;
using R20_Labo.ViewModels;


namespace R20_Labo.Controllers
{
    public class StatsController : Controller
    {
        private readonly SussyKartContext _context;

        public StatsController(SussyKartContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // Section 1 : Compléter ToutesParticipations (Obligatoire)
        public IActionResult ToutesParticipations()
        {
            // Obtenir les participations grâce à une vue SQL mais n'obtenez que les 30 premières participations

            return View(new FiltreParticipationVM());
        }

        public IActionResult ToutesParticipationsFiltre(FiltreParticipationVM fpvm)
        {
            // Obtenir TOUTES les participations grâce à une vue SQL (et on va filtrer ensuite)

            if (fpvm.Pseudo != null)
            {
                // ...
            }

            if (fpvm.Course != "Toutes")
            {
                // ...
            }

            // Trier soit par date, soit par chrono (fpvm.Ordre) de manière croissante ou décroissante (fpvm.TypeOrdre)

            // Sauter des paquets de 30 participations si la page est supérieure à 1

            return View("ToutesParticipations", fpvm);
        }


    }
}

