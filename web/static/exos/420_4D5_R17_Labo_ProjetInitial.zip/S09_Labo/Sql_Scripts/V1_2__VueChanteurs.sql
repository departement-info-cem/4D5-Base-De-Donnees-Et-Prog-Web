
	USE S09_Labo
    GO
-- Nouvelle vue
	
	--CREATE VIEW Musique.VW_ChanteurNbChansons AS
	
	---- ?
	
	--GO
	
	-- Résultat souhaité : id du chanteur, nom du chanteur, date de naissance et son nombre de chansons
	
	-- ChanteurID |Nom  | Date de naissance |Nombre de chansons
	-- -----------|-----|-------------------|-------------------