﻿using S09_Labo.Models;

namespace S09_Labo.ViewModels
{
    public class ChanteurEtNbChansonsViewModel
    {
        public Chanteur Chanteur { get; set; } = null!;

        public int NbChansons { get; set; }
    }
}
