
	-- Nouvelle colonne pour la PK de Musique.Chanteur et la FK de Musique.Chanson

	
	-- Supprimer les anciennes contraintes FK puis PK (attention, l'ordre de suppression est important ici)
	

	
	-- Nouvelles contraintes PK puis FK
	

	
	-- Remplir la nouvelle colonne FK et faire en sorte que le nouveau champ que vous avez crée ChanteurID n'est pas null maintenant
	

	
	-- Supprimer l'ancienne colonne FK de Musique.Chanson (On veut garder le nom des chanteurs, donc on ne supprime pas l'ancienne PK !)
	

	